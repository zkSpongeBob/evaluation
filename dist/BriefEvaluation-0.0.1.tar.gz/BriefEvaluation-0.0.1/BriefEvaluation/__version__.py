__package__ = 'BriefEvaluation'
__description__ = 'This is a package for doing a comprehensive evaluation'
__url__ = 'https://gitee.com/zkspongebob/evaluation'
__version__ = "0.0.1"
__version_info__ = (0, 0, 1, 0)
__author__ = 'zkSpongeBob'
__author_email__ = 'zkSpongeBon@126.com'
__license__ = 'MIT'