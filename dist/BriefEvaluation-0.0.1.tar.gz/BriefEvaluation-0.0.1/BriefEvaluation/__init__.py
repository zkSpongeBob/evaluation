from . import topsis
from .__version__ import __author__, __author_email__, __license__
from .__version__ import __description__, __url__, __version__

